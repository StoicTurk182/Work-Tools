# Define credentials
$username = 'andrewmailbox.ajj@googlemail.com'
$password = ConvertTo-SecureString '$Tenakoutou$' -AsPlainText -Force

# Encrypt and save only the password
$encryptedPassword = $password | ConvertFrom-SecureString
$credentials = @{
    Username = $username
    Password = $encryptedPassword
}

# Save credentials as a JSON object in one file
$credentials | ConvertTo-Json | Set-Content -Path 'C:\Users\Orion\Desktop\Credentials\credentials.json'
